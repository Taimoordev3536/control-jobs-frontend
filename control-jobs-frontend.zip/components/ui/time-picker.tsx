"use client"

import { useState, useRef, useEffect } from "react"
import { Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { createPortal } from "react-dom"

interface TimePickerProps {
  value?: string
  onChange?: (time: string) => void
  className?: string
}

export function TimePicker({ value = "", onChange, className }: TimePickerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isPositioned, setIsPositioned] = useState(false)
  const [selectedHour, setSelectedHour] = useState("08")
  const [selectedMinute, setSelectedMinute] = useState("00")
  const [selectedPeriod, setSelectedPeriod] = useState("AM")
  const dropdownRef = useRef<HTMLDivElement>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)
  const hourListRef = useRef<HTMLDivElement>(null)
  const minuteListRef = useRef<HTMLDivElement>(null)

  // Parse initial value
  useEffect(() => {
    if (value) {
      const [time, period] = value.split(" ")
      if (time && period) {
        const [hour, minute] = time.split(":")
        setSelectedHour(hour)
        setSelectedMinute(minute)
        setSelectedPeriod(period)
      } else if (time) {
        const [hour, minute] = time.split(":")
        const hourNum = Number.parseInt(hour)
        if (hourNum === 0) {
          setSelectedHour("12")
          setSelectedPeriod("AM")
        } else if (hourNum <= 12) {
          setSelectedHour(hour.padStart(2, "0"))
          setSelectedPeriod("AM")
        } else {
          setSelectedHour((hourNum - 12).toString().padStart(2, "0"))
          setSelectedPeriod("PM")
        }
        setSelectedMinute(minute || "00")
      }
    }
  }, [value])
  // We no longer need the debug logging as we've fixed the issues

  // Close dropdown when clicking outside
  useEffect(() => {
    if (!isOpen) return;

    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false)
        setIsPositioned(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [isOpen])

  const hours = ["00","01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
  const minutes = [
    "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18",
    "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37",
    "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56",
    "57", "58", "59",
  ]

  // Time selection is now handled directly in the select onChange handlers

  const formatDisplayTime = () => {
    if (!value) return "--:--"
    return value
  }

  // Dynamically determine dropdown position
  const [dropdownStyle, setDropdownStyle] = useState<React.CSSProperties>({
    position: "absolute",
    top: 0,
    left: 0,
    zIndex: 9999,
    opacity: 0 // Start with opacity 0
  })

  useEffect(() => {
    setIsPositioned(false) // Reset positioning when dropdown opens/closes
    
    if (isOpen && buttonRef.current) {
      const buttonRect = buttonRef.current.getBoundingClientRect()
      const spaceBelow = window.innerHeight - buttonRect.bottom
      const spaceAbove = buttonRect.top
      
      // Calculate position - prefer below, but go above if not enough space
      if (spaceBelow >= 160 || spaceBelow > spaceAbove) {
        setDropdownStyle({
          position: "absolute",
          top: buttonRect.bottom + window.scrollY + 2, // Small offset for better visual appearance
          left: buttonRect.left + window.scrollX - 65, // Offset to center the dropdown based on new width
          zIndex: 9999,
          opacity: 1 // Make visible after positioned
        })
      } else {
        setDropdownStyle({
          position: "absolute",
          top: buttonRect.top + window.scrollY - 162, // Height of dropdown + small offset
          left: buttonRect.left + window.scrollX - 65, // Offset to center the dropdown based on new width
          zIndex: 9999,
          opacity: 1 // Make visible after positioned
        })
      }
      
      // Set positioned flag after a small delay to ensure styles are applied
      setTimeout(() => setIsPositioned(true), 10)
    }
  }, [isOpen])

  // Add any custom styles if needed
  useEffect(() => {
    if (typeof document === "undefined") return
    const id = "timepicker-select-styles"
    if (document.getElementById(id)) return
    const style = document.createElement("style")
    style.id = id
    style.innerHTML = `
      .time-select option:checked {
        background-color: #3b82f6;
        color: white;
      }
    `
    document.head.appendChild(style)
    return () => {
      const el = document.getElementById(id)
      if (el) el.remove()
    }
  }, [])

  return (
    <div className="relative z-50">
      <Button
        ref={buttonRef}
        variant="ghost"
        size="sm"
        className={cn("h-6 w-6 p-0", className)}
        onClick={() => {
          if (isOpen) {
            setIsOpen(false)
            setIsPositioned(false)
          } else {
            setIsOpen(true)
          }
        }}
        type="button"
      >
        <Clock className="h-3 w-3" />
      </Button>

      {isOpen && isPositioned && typeof document !== 'undefined' && createPortal(
        <div
          ref={dropdownRef}
          className="bg-white border border-gray-300 rounded-md shadow-lg p-2 z-50"
          style={{ 
            ...dropdownStyle,
            width: "130px",
            transition: "opacity 0.1s ease-in-out"
          }}
        >
          <div className="space-y-2">
            <div className="flex gap-0.5">
              {/* Hours Column */}
              <div className="w-[40px]">
                <div className="text-xs font-medium text-center mb-1 text-gray-600">Hour</div>
                <select
                  ref={hourListRef}
                  className="h-24 w-full border rounded text-xs p-0 focus:ring-0 focus:border-gray-300"
                  size={8}
                  value={selectedHour}
                  onChange={(e) => {
                    const hour = e.target.value;
                    setSelectedHour(hour);
                    const timeString = `${hour}:${selectedMinute} ${selectedPeriod}`;
                    onChange?.(timeString);
                  }}
                >
                  {hours.map((hour) => (
                    <option 
                      key={hour} 
                      value={hour}
                      className="text-center py-0.5"
                    >
                      {hour}
                    </option>
                  ))}
                </select>
              </div>

              {/* Minutes Column */}
              <div className="w-[40px]">
                <div className="text-xs font-medium text-center mb-1 text-gray-600">Min</div>
                <select
                  ref={minuteListRef}
                  className="h-24 w-full border rounded text-xs p-0 focus:ring-0 focus:border-gray-300"
                  size={8}
                  value={selectedMinute}
                  onChange={(e) => {
                    const minute = e.target.value;
                    setSelectedMinute(minute);
                    const timeString = `${selectedHour}:${minute} ${selectedPeriod}`;
                    onChange?.(timeString);
                  }}
                >
                  {minutes.map((minute) => (
                    <option 
                      key={minute} 
                      value={minute}
                      className="text-center py-0.5"
                    >
                      {minute}
                    </option>
                  ))}
                </select>
              </div>

              {/* AM/PM Column */}
              <div className="w-[40px]">
                <div className="text-xs font-medium text-center mb-1 text-gray-600">Period</div>
                <select
                  className="w-full border rounded text-xs p-0 h-12 focus:ring-0 focus:border-gray-300"
                  size={2}
                  value={selectedPeriod}
                  onChange={(e) => {
                    const period = e.target.value;
                    setSelectedPeriod(period);
                    const timeString = `${selectedHour}:${selectedMinute} ${period}`;
                    onChange?.(timeString);
                  }}
                >
                  {["AM", "PM"].map((period) => (
                    <option 
                      key={period} 
                      value={period}
                      className="text-center py-0.5"
                    >
                      {period}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            {/* Done Button */}
            <button
              className="w-full bg-blue-500 hover:bg-blue-600 text-white text-xs py-0.5 rounded"
              onClick={() => {
                setIsOpen(false)
                setIsPositioned(false)
              }}
            >
              Done
            </button>
          </div>
        </div>,
        document.body
      )}
    </div>
  )
}