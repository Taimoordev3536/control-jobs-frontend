"use client"

import { useState, useEffect } from "react"
import {
  Building,
  Clock,
  CheckCircle,
  Eye,
  MapPin,
  Activity,
  Timer,
  Calendar,
  Shield,
  QrCode,
  Wifi,
  Navigation,
  Camera,
  Smartphone,
  Send,
  ClipboardList,
  Search,
  User,
  ArrowLeft,
  MessageSquare,
  Star,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { useTranslation } from "@/hooks/use-translation"
import { useAuth } from "@/hooks/use-auth"

interface Job {
  id: number
  jobId: string
  title: string
  description: string
  worker: {
    name: string
    avatar: string
    completedJobs: number
  }
  client: {
    name: string
    address: string
    phone: string
  }
  schedule: {
    date: string
    startTime: string
    endTime: string
    estimatedHours: number
  }
  status: "pending" | "active" | "completed"
  checkin?: {
    time: string
    method: string
    location: { lat: number; lng: number; accuracy: string }
    photo: boolean
    ip: string
    wifi: string
  }
  checkout?: {
    time: string
    method: string
  }
  timeTracking: {
    actualHours: number
    breaks: Array<{ start: string; end: string; duration: number }>
    activities: Array<{ time: string; action: string; location: string }>
  }
  qrCode: {
    code: string
    generatedAt: string
    expiresAt: string
  }
  verificationMethods: string[]
  geofence: {
    enabled: boolean
    radius: number
    center: { lat: number; lng: number }
  }
  checklist: Array<{ task: string; completed: boolean; time?: string }>
  alerts: Array<{ type: string; message: string; time: string }>
  feedback?: string
  surveyCompleted?: boolean
  clientSurvey?: {
    rating: number
    comments: string
    submitted: boolean
    submittedAt?: Date
  }
}

interface ClientStats {
  totalJobs: number
  activeJobs: number
  completedJobs: number
  totalSpent: number
  satisfactionRate: number
  responseTime: number
  savings: number
}

interface Survey {
  jobId: number
  workerName: string
  jobTitle: string
  feedback: string
  categories: {
    punctuality: number
    quality: number
    professionalism: number
    communication: number
  }
  wouldRecommend: boolean
  completedAt: string
}

const ratingLabels = [
  { value: 1, label: "Very Poor" },
  { value: 2, label: "Poor" },
  { value: 3, label: "Average" },
  { value: 4, label: "Good" },
  { value: 5, label: "Excellent" },
]

export default function ClientDashboard() {
  const { t } = useTranslation()
  const { session } = useAuth()
  const [currentTime, setCurrentTime] = useState(new Date())
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("jobs")
  const [surveyData, setSurveyData] = useState<Partial<Survey>>({})
  const [searchTerm, setSearchTerm] = useState("")

  // View state management - similar to worker dashboard
  const [currentView, setCurrentView] = useState("dashboard")
  const [selectedJobDetails, setSelectedJobDetails] = useState<Job | null>(null)

  // Survey states
  const [surveyJob, setSurveyJob] = useState<Job | null>(null)
  const [surveyRating, setSurveyRating] = useState<number>(0)
  const [surveyComments, setSurveyComments] = useState("")

  const [clientStats, setClientStats] = useState<ClientStats>({
    totalJobs: 18,
    activeJobs: 3,
    completedJobs: 15,
    totalSpent: 45000,
    satisfactionRate: 92,
    responseTime: 2.5,
    savings: 8500,
  })

  const [jobs, setJobs] = useState<Job[]>([
    {
      id: 1,
      jobId: "JOB-1247",
      title: "Premium Kitchen Deep Clean",
      description: "Complete kitchen sanitization including appliances, cabinets, and deep cleaning",
      worker: {
        name: "Sarah Johnson",
        avatar: "👩‍🦰",
        completedJobs: 143,
      },
      client: {
        name: "John Smith",
        address: "123 Main St, Kitchen Area",
        phone: "+1 (555) 123-4567",
      },
      schedule: {
        date: "2024-07-24",
        startTime: "09:00 AM",
        endTime: "12:00 PM",
        estimatedHours: 3,
      },
      status: "active",
      checkin: {
        time: "09:05 AM",
        method: "qr-code",
        location: { lat: 40.7128, lng: -74.006, accuracy: "5m" },
        photo: true,
        ip: "192.168.1.15",
        wifi: "HomeWiFi_Kitchen",
      },
      timeTracking: {
        actualHours: 2.5,
        breaks: [{ start: "10:30 AM", end: "10:45 AM", duration: 15 }],
        activities: [
          { time: "09:05 AM", action: "Checked in via QR code", location: "Kitchen entrance" },
          { time: "09:10 AM", action: "Started deep cleaning checklist", location: "Kitchen" },
          { time: "10:30 AM", action: "Break started", location: "Kitchen" },
          { time: "10:45 AM", action: "Break ended, resumed work", location: "Kitchen" },
        ],
      },
      qrCode: {
        code: "SECURE-JOB-001-KITCHEN-20240724",
        generatedAt: "2024-07-24T08:45:00Z",
        expiresAt: "2024-07-24T13:00:00Z",
      },
      verificationMethods: ["qr-code", "gps-location", "wifi-network", "photo-verification"],
      geofence: {
        enabled: true,
        radius: 50,
        center: { lat: 40.7128, lng: -74.006 },
      },
      checklist: [
        { task: "Clean countertops and surfaces", completed: true, time: "09:15 AM" },
        { task: "Deep clean appliances", completed: true, time: "09:45 AM" },
        { task: "Sanitize sink and faucet", completed: true, time: "10:15 AM" },
        { task: "Clean cabinets inside/outside", completed: false },
        { task: "Mop and sanitize floor", completed: false },
      ],
      alerts: [{ type: "info", message: "Worker checked in 5 minutes late", time: "09:05 AM" }],
    },
    {
      id: 2,
      jobId: "JOB-1248",
      title: "Office Space Deep Clean",
      description: "Complete office cleaning including desks, conference rooms, and common areas",
      worker: {
        name: "Mike Davis",
        avatar: "👨‍🦲",
        completedJobs: 87,
      },
      client: {
        name: "Tech Solutions Inc",
        address: "456 Oak Avenue, Suite 200",
        phone: "+1 (555) 987-6543",
      },
      schedule: {
        date: "2024-07-20",
        startTime: "02:00 PM",
        endTime: "06:00 PM",
        estimatedHours: 4,
      },
      status: "completed",
      checkin: {
        time: "02:00 PM",
        method: "gps-location",
        location: { lat: 40.7589, lng: -73.9851, accuracy: "3m" },
        photo: true,
        ip: "192.168.1.20",
        wifi: "OfficeWiFi_Main",
      },
      checkout: {
        time: "06:15 PM",
        method: "qr-code",
      },
      timeTracking: {
        actualHours: 4.25,
        breaks: [{ start: "04:00 PM", end: "04:15 PM", duration: 15 }],
        activities: [
          { time: "02:00 PM", action: "Checked in via GPS", location: "Office entrance" },
          { time: "02:05 PM", action: "Started office cleaning", location: "Main office" },
          { time: "04:00 PM", action: "Break started", location: "Break room" },
          { time: "04:15 PM", action: "Break ended, resumed work", location: "Conference room" },
          { time: "06:15 PM", action: "Checked out via QR code", location: "Office exit" },
        ],
      },
      qrCode: {
        code: "SECURE-JOB-002-OFFICE-20240720",
        generatedAt: "2024-07-20T13:30:00Z",
        expiresAt: "2024-07-20T18:30:00Z",
      },
      verificationMethods: ["qr-code", "gps-location", "ip-address"],
      geofence: {
        enabled: true,
        radius: 30,
        center: { lat: 40.7589, lng: -73.9851 },
      },
      checklist: [
        { task: "Clean all desks and workstations", completed: true, time: "02:30 PM" },
        { task: "Sanitize conference rooms", completed: true, time: "03:15 PM" },
        { task: "Clean kitchen/break room", completed: true, time: "04:30 PM" },
        { task: "Vacuum all carpeted areas", completed: true, time: "05:30 PM" },
        { task: "Empty trash and replace liners", completed: true, time: "06:00 PM" },
      ],
      alerts: [],
      feedback: "Excellent work! Very thorough and professional.",
      surveyCompleted: true,
      clientSurvey: {
        rating: 5,
        comments: "Outstanding service! The worker was punctual, professional, and did an excellent job.",
        submitted: true,
        submittedAt: new Date("2024-07-20T18:30:00Z"),
      },
    },
  ])

  const [completedSurveys, setCompletedSurveys] = useState<Survey[]>([
    {
      jobId: 2,
      workerName: "Mike Davis",
      jobTitle: "Office Space Deep Clean",
      feedback: "Excellent work! Very thorough and professional.",
      categories: {
        punctuality: 5,
        quality: 5,
        professionalism: 4,
        communication: 5,
      },
      wouldRecommend: true,
      completedAt: "2024-07-20T18:30:00Z",
    },
  ])

  useEffect(() => {
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
    }, 1000)
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    })
  }

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "active":
        return {
          color:
            "bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800",
          icon: Activity,
          dot: "bg-green-500",
        }
      case "pending":
        return {
          color:
            "bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800",
          icon: Clock,
          dot: "bg-red-500",
        }
      case "completed":
        return {
          color:
            "bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-900/20 dark:text-purple-400 dark:border-purple-800",
          icon: CheckCircle,
          dot: "bg-purple-500",
        }
      default:
        return {
          color:
            "bg-gray-50 text-gray-700 border border-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700",
          icon: Clock,
          dot: "bg-gray-500",
        }
    }
  }

  const getVerificationIcon = (method: string) => {
    switch (method) {
      case "qr-code":
        return { icon: QrCode, name: "QR Code Scan", color: "text-purple-600 dark:text-purple-400" }
      case "gps-location":
        return { icon: Navigation, name: "GPS Geofencing", color: "text-green-600 dark:text-green-400" }
      case "wifi-network":
        return { icon: Wifi, name: "WiFi Detection", color: "text-blue-600 dark:text-blue-400" }
      case "ip-address":
        return { icon: Smartphone, name: "IP Verification", color: "text-orange-600 dark:text-orange-400" }
      case "photo-verification":
        return { icon: Camera, name: "Photo Capture", color: "text-pink-600 dark:text-pink-400" }
      default:
        return { icon: Shield, name: method, color: "text-gray-600 dark:text-gray-400" }
    }
  }

  const calculateProgress = (checklist: Array<{ task: string; completed: boolean; time?: string }>) => {
    const completed = checklist.filter((item) => item.completed).length
    return Math.round((completed / checklist.length) * 100)
  }

  const generateQRCode = (jobId: number) => {
    const timestamp = Date.now()
    setJobs(
      jobs.map((job) =>
        job.id === jobId
          ? {
              ...job,
              qrCode: {
                ...job.qrCode,
                code: `SECURE-JOB-${String(jobId).padStart(3, "0")}-${timestamp}`,
                generatedAt: new Date().toISOString(),
              },
            }
          : job,
      ),
    )
  }

  const submitSurvey = (jobId: number) => {
    const job = jobs.find((j) => j.id === jobId)
    if (!job || !surveyData.feedback) return

    const newSurvey: Survey = {
      jobId,
      workerName: job.worker.name,
      jobTitle: job.title,
      feedback: surveyData.feedback,
      categories: surveyData.categories || {
        punctuality: 5,
        quality: 5,
        professionalism: 5,
        communication: 5,
      },
      wouldRecommend: surveyData.wouldRecommend || true,
      completedAt: new Date().toISOString(),
    }

    setCompletedSurveys([...completedSurveys, newSurvey])
    setJobs(
      jobs.map((job) =>
        job.id === jobId
          ? {
              ...job,
              feedback: surveyData.feedback,
              surveyCompleted: true,
            }
          : job,
      ),
    )
    setSurveyData({})
  }

  const handleViewDetails = (job: Job) => {
    setSelectedJobDetails(job)
    setCurrentView("jobDetails")
  }

  const handleFillSurvey = (job: Job) => {
    setSurveyJob(job)
    setSurveyRating(0)
    setSurveyComments("")
    setCurrentView("survey")
  }

  const handleClientSurveySubmit = () => {
    if (surveyRating === 0 || !surveyJob) return

    const newSurvey = {
      rating: surveyRating,
      comments: surveyComments,
      submitted: true,
      submittedAt: new Date(),
    }

    setJobs((prev) => prev.map((job) => (job.id === surveyJob.id ? { ...job, clientSurvey: newSurvey } : job)))

    // Reset survey form and go back to dashboard
    setSurveyJob(null)
    setSurveyRating(0)
    setSurveyComments("")
    setCurrentView("dashboard")
  }

  // Survey Full Page View
  const renderSurveyView = () => (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-4 mb-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentView("dashboard")}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Service Survey</h1>
            <p className="text-gray-600 dark:text-gray-400 text-sm">{surveyJob?.title}</p>
          </div>
        </div>
      </div>

      <div className="max-w-[800px] mx-auto p-4 space-y-6">
        {/* Job Info Card */}
        <Card className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
          <CardContent className="p-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 bg-purple-100 dark:bg-purple-900/20 rounded-full">
                <MessageSquare className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">{surveyJob?.title}</h2>
                <p className="text-gray-600 dark:text-gray-400">Worker: {surveyJob?.worker.name}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <MapPin className="w-4 h-4" />
                <span>{surveyJob?.client.address}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <Clock className="w-4 h-4" />
                <span>
                  {surveyJob?.schedule.startTime} - {surveyJob?.schedule.endTime}
                </span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <Building className="w-4 h-4" />
                <span>{surveyJob?.client.name}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <Badge
                  variant="outline"
                  className="font-mono bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                >
                  {surveyJob?.jobId}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Survey Form */}
        <Card className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
          <CardContent className="p-6">
            <div className="space-y-6">
              <div>
                <label className="text-lg font-medium text-gray-900 dark:text-white mb-4 block">
                  How satisfied are you with the job? <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-5 gap-3">
                  {ratingLabels.map((rating) => (
                    <button
                      key={rating.value}
                      onClick={() => setSurveyRating(rating.value)}
                      className={`p-4 rounded-lg border-2 text-center transition-all duration-200 ${
                        surveyRating === rating.value
                          ? "border-purple-600 bg-purple-600 text-white"
                          : "border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:border-purple-300 hover:bg-purple-50 dark:hover:bg-purple-900/20"
                      }`}
                    >
                      <div className="text-2xl font-bold mb-1">{rating.value}</div>
                      <div className="text-sm">{rating.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-lg font-medium text-gray-900 dark:text-white mb-3 block">Any comments?</label>
                <Textarea
                  placeholder="Share your thoughts, suggestions, or feedback about the job..."
                  value={surveyComments}
                  onChange={(e) => setSurveyComments(e.target.value)}
                  className="min-h-[120px] resize-none text-base"
                />
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  onClick={handleClientSurveySubmit}
                  disabled={surveyRating === 0}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-3 text-base"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Submit Survey
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setCurrentView("dashboard")}
                  className="px-8 py-3 bg-transparent border-gray-300 dark:border-gray-600 text-base"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center">
        <div className="relative">
          <div className="w-16 h-16 border-4 border-gray-200 dark:border-gray-800 rounded-full animate-spin border-t-purple-600"></div>
          <div className="absolute inset-0 w-16 h-16 border-4 border-transparent rounded-full animate-ping border-t-purple-400"></div>
        </div>
      </div>
    )
  }

  // Job Details View - Full Page like Worker Dashboard Check-in
  const renderJobDetailsView = () => (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 p-4 mb-4">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCurrentView("dashboard")}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Job Details</h1>
            <p className="text-gray-600 dark:text-gray-400 text-sm">{selectedJobDetails?.title}</p>
          </div>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto p-4 space-y-4">
        <Card className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
          <CardContent className="p-4">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-3">{selectedJobDetails?.title}</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{selectedJobDetails?.client.address}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <Clock className="w-4 h-4" />
                <span className="text-sm">
                  {selectedJobDetails?.schedule.startTime} - {selectedJobDetails?.schedule.endTime}
                </span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <Building className="w-4 h-4" />
                <span className="text-sm">{selectedJobDetails?.client.name}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600 dark:text-gray-400">
                <User className="w-4 h-4" />
                <span className="text-sm">Worker: {selectedJobDetails?.worker.name}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* QR Code Section */}
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Job QR Code</h2>
          <Card className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
            <CardContent className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 dark:bg-gray-800 p-6 rounded-lg border-2 border-dashed border-gray-300 dark:border-gray-600 text-center">
                  <QrCode className="w-24 h-24 mx-auto text-gray-400 mb-4" />
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                    Worker scans this code to check in/out
                  </p>
                  <p className="text-xs font-mono bg-white dark:bg-gray-900 p-2 rounded border break-all">
                    {selectedJobDetails?.qrCode.code}
                  </p>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-900 dark:text-white">Generated At:</label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {selectedJobDetails?.qrCode.generatedAt &&
                        new Date(selectedJobDetails.qrCode.generatedAt).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-900 dark:text-white">Expires At:</label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {selectedJobDetails?.qrCode.expiresAt &&
                        new Date(selectedJobDetails.qrCode.expiresAt).toLocaleString()}
                    </p>
                  </div>
                  <Button
                    onClick={() => selectedJobDetails && generateQRCode(selectedJobDetails.id)}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    Generate New QR Code
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Verification Methods */}
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Security Verification Methods</h2>
          <div className="space-y-3">
            {selectedJobDetails &&
              selectedJobDetails.verificationMethods.map((method) => {
                const verification = getVerificationIcon(method)
                const VerificationIcon = verification.icon

                return (
                  <Card key={method} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center text-purple-600 dark:text-purple-400">
                          <VerificationIcon className="w-5 h-5" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 dark:text-white">{verification.name}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {method === "gps-location" && "Verify worker location using GPS coordinates"}
                            {method === "wifi-network" && "Detect connection to workplace WiFi network"}
                            {method === "ip-address" && "Verify using IP address range"}
                            {method === "qr-code" && "Scan QR code at designated location"}
                            {method === "photo-verification" && "Capture photo for visual confirmation"}
                          </p>
                        </div>
                        <Badge
                          variant="secondary"
                          className="bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400"
                        >
                          ENABLED
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
          </div>
        </div>

        {/* Task Checklist */}
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
            Task Checklist ({selectedJobDetails && selectedJobDetails.checklist.filter((t) => t.completed).length}/
            {selectedJobDetails?.checklist.length})
          </h2>
          <div className="space-y-3">
            {selectedJobDetails &&
              selectedJobDetails.checklist.map((task, index) => (
                <Card
                  key={index}
                  className={`border ${
                    task.completed
                      ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800"
                      : "bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800"
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div
                          className={`w-6 h-6 rounded-full mr-3 flex items-center justify-center ${
                            task.completed ? "bg-green-500" : "bg-gray-400"
                          }`}
                        >
                          {task.completed && <CheckCircle className="w-4 h-4 text-white" />}
                        </div>
                        <div>
                          <span
                            className={`text-sm font-medium ${
                              task.completed ? "text-green-800 dark:text-green-200" : "text-gray-900 dark:text-white"
                            }`}
                          >
                            {task.task}
                          </span>
                          {task.completed && task.time && (
                            <p className="text-xs text-green-600 dark:text-green-400 mt-1">Completed at {task.time}</p>
                          )}
                        </div>
                      </div>
                      {task.completed && (
                        <Badge
                          variant="secondary"
                          className="bg-green-100 dark:bg-green-900/20 text-green-700 dark:text-green-400"
                        >
                          DONE
                        </Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>

        {/* Activity Timeline */}
        {selectedJobDetails && selectedJobDetails.timeTracking.activities.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Activity Timeline</h2>
            <div className="space-y-3">
              {selectedJobDetails.timeTracking.activities.map((activity, index) => (
                <Card key={index} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-3 h-3 bg-purple-600 rounded-full mt-2 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{activity.action}</p>
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                          {activity.time} • {activity.location}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Time Tracking Summary */}
        {selectedJobDetails && (
          <Card className="bg-blue-50 border-blue-200 dark:bg-blue-900/20 dark:border-blue-800">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Timer className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">Time Summary</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-blue-800 dark:text-blue-200 font-medium">Expected:</span>
                      <p className="text-blue-900 dark:text-blue-100">{selectedJobDetails.schedule.estimatedHours}h</p>
                    </div>
                    <div>
                      <span className="text-blue-800 dark:text-blue-200 font-medium">Actual:</span>
                      <p className="text-blue-900 dark:text-blue-100">
                        {selectedJobDetails.status === "completed"
                          ? `${selectedJobDetails.timeTracking.actualHours}h`
                          : selectedJobDetails.status === "active"
                            ? "In Progress"
                            : "Not Started"}
                      </p>
                    </div>
                    <div>
                      <span className="text-blue-800 dark:text-blue-200 font-medium">Breaks:</span>
                      <p className="text-blue-900 dark:text-blue-100">
                        {selectedJobDetails.timeTracking.breaks.length} breaks
                      </p>
                    </div>
                    <div>
                      <span className="text-blue-800 dark:text-blue-200 font-medium">Status:</span>
                      <p className="text-blue-900 dark:text-blue-100 capitalize">{selectedJobDetails.status}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <Button variant="outline" className="flex-1 bg-transparent">
            <MessageSquare className="w-4 h-4 mr-2" />
            Message Worker
          </Button>
          <Button variant="outline" className="flex-1 bg-transparent">
            <Calendar className="w-4 h-4 mr-2" />
            Reschedule Job
          </Button>
          {selectedJobDetails && !selectedJobDetails.clientSurvey?.submitted && (
            <Button
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
              onClick={() => handleFillSurvey(selectedJobDetails)}
            >
              <Star className="w-4 h-4 mr-2" />
              Fill Survey
            </Button>
          )}
        </div>
      </div>
    </div>
  )

  // Render different views based on current state - like worker dashboard
  if (currentView === "jobDetails") {
    return renderJobDetailsView()
  }

  if (currentView === "survey") {
    return renderSurveyView()
  }

  // Main Dashboard View
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      <div className="max-w-[1400px] mx-auto p-4 space-y-4">
        {/* Header - Matching Worker Dashboard Style */}
        <Card className="border border-gray-200 dark:border-gray-800 shadow-sm bg-white dark:bg-gray-900">
          <CardContent className="p-4">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-600 rounded-lg shadow-sm">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Client Dashboard</h1>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {formatTime(currentTime)} •{" "}
                    {currentTime.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search jobs..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 w-64 h-9"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards - Matching Worker Dashboard Gray Style */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {[
            {
              label: "ACTIVE JOBS",
              value: clientStats.activeJobs,
              icon: Activity,
            },
            {
              label: "COMPLETED JOBS",
              value: clientStats.completedJobs,
              icon: CheckCircle,
            },
            {
              label: "TOTAL SPENT",
              value: `$${(clientStats.totalSpent / 1000).toFixed(0)}K`,
              icon: Building,
            },
            {
              label: "SATISFACTION RATE",
              value: `${clientStats.satisfactionRate}%`,
              icon: CheckCircle,
            },
          ].map((stat, index) => (
            <Card
              key={index}
              className="border border-gray-200 dark:border-gray-800 hover:shadow-md transition-all duration-300 hover:scale-105 group bg-white dark:bg-gray-900"
            >
              <CardContent className="p-3">
                <div className="w-full h-0.5 bg-gray-500 rounded-full mb-2"></div>
                <div className="flex items-center justify-between mb-2">
                  <div className="p-1.5 rounded-lg bg-gray-500 group-hover:scale-110 transition-transform duration-300">
                    <stat.icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-gray-900 dark:text-white group-hover:scale-110 transition-transform duration-300">
                      {stat.value}
                    </div>
                  </div>
                </div>
                <div className="text-gray-500 dark:text-gray-400 font-medium text-xs uppercase tracking-wider">
                  {stat.label}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs - Updated Style */}
        <Card className="border border-gray-200 dark:border-gray-800 shadow-sm bg-white dark:bg-gray-900">
          <CardContent className="p-4">
            {/* Custom Tab Navigation */}
            <div className="flex border-b border-gray-200 dark:border-gray-700 mb-4">
              <button
                onClick={() => setActiveTab("jobs")}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === "jobs"
                    ? "border-purple-600 text-purple-600 bg-purple-50 dark:bg-purple-900/20 dark:text-purple-400"
                    : "border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                }`}
              >
                Jobs
              </button>
              <button
                onClick={() => setActiveTab("history")}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === "history"
                    ? "border-purple-600 text-purple-600 bg-purple-50 dark:bg-purple-900/20 dark:text-purple-400"
                    : "border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                }`}
              >
                History
              </button>
              <button
                onClick={() => setActiveTab("surveys")}
                className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === "surveys"
                    ? "border-purple-600 text-purple-600 bg-purple-50 dark:bg-purple-900/20 dark:text-purple-400"
                    : "border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200"
                }`}
              >
                Surveys
              </button>
            </div>

            {/* Tab Content */}
            {activeTab === "jobs" && (
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                {jobs
                  .filter((job) => job.status === "pending" || job.status === "active")
                  .map((job) => {
                    const statusConfig = getStatusConfig(job.status)
                    const progress = calculateProgress(job.checklist)
                    const StatusIcon = statusConfig.icon

                    return (
                      <Card
                        key={job.id}
                        className="group border border-gray-200 dark:border-gray-800 hover:shadow-lg transition-all duration-300 hover:scale-[1.02] hover:-translate-y-1 bg-white dark:bg-gray-900"
                      >
                        {/* Status Indicator Line */}
                        <div
                          className={`w-full h-0.5 ${
                            job.status === "pending"
                              ? "bg-red-500"
                              : job.status === "active"
                                ? "bg-green-500"
                                : job.status === "completed"
                                  ? "bg-purple-500"
                                  : "bg-gray-500"
                          }`}
                        ></div>
                        <CardHeader className="pb-2">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${statusConfig.dot}`}></div>
                                <h3 className="text-lg font-bold text-gray-900 dark:text-white">{job.title}</h3>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge
                                  variant="outline"
                                  className="text-xs font-mono bg-gray-100 dark:bg-gray-800 h-5 border-gray-200 dark:border-gray-700"
                                >
                                  {job.jobId}
                                </Badge>
                                <Badge className={`${statusConfig.color} flex items-center gap-1 h-6 text-xs`}>
                                  <StatusIcon className="w-3 h-3" />
                                  {job.status === "active"
                                    ? "In Progress"
                                    : job.status === "pending"
                                      ? "Scheduled"
                                      : job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </CardHeader>

                        <CardContent className="space-y-3 pt-0">
                          {/* Client & Location Info */}
                          <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                                <Building className="w-3 h-3" />
                                <span className="text-xs font-medium uppercase tracking-wide">Client</span>
                              </div>
                              <div className="text-xs font-semibold text-gray-900 dark:text-white truncate">
                                {job.client.name}
                              </div>
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                                <MapPin className="w-3 h-3" />
                                <span className="text-xs font-medium uppercase tracking-wide">Location</span>
                              </div>
                              <div className="text-xs font-semibold text-gray-900 dark:text-white truncate">
                                {job.client.address}
                              </div>
                            </div>
                          </div>

                          {/* Shift Time */}
                          <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                                <span className="text-sm font-medium text-gray-900 dark:text-white">
                                  {job.schedule.startTime} - {job.schedule.endTime}
                                </span>
                              </div>
                              <Badge
                                variant="secondary"
                                className="text-xs bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
                              >
                                {job.schedule.estimatedHours}h
                              </Badge>
                            </div>
                          </div>

                          {/* Hours Information */}
                          <div className="grid grid-cols-2 gap-2">
                            <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded-md text-center">
                              <div className="text-xs text-gray-600 dark:text-gray-400 font-medium mb-0.5">
                                Expected Hours
                              </div>
                              <div className="text-xs font-bold text-gray-900 dark:text-white">
                                {job.schedule.estimatedHours}h
                              </div>
                            </div>
                            <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded-md text-center">
                              <div className="text-xs text-gray-600 dark:text-gray-400 font-medium mb-0.5">
                                Actual Hours
                              </div>
                              <div className="text-xs font-bold text-gray-900 dark:text-white">
                                {job.status === "completed"
                                  ? `${job.timeTracking.actualHours}h`
                                  : job.status === "active"
                                    ? "In Progress"
                                    : "---"}
                              </div>
                            </div>
                          </div>

                          {/* Tasks Progress */}
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
                                Tasks Progress
                              </span>
                              <span className="text-xs font-bold text-purple-600 dark:text-purple-400">
                                {job.checklist.filter((t) => t.completed).length}/{job.checklist.length}
                              </span>
                            </div>
                            <div className="relative">
                              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                                <div
                                  className="bg-purple-600 h-1.5 rounded-full transition-all duration-1000 ease-out"
                                  style={{ width: `${progress}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>

                          {/* Signing Methods */}
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-600 dark:text-gray-400">Sign-in methods:</span>
                            <div className="flex gap-1">
                              {job.verificationMethods.includes("qr-code") && (
                                <div className="p-1 bg-purple-100 dark:bg-purple-900/20 rounded">
                                  <QrCode className="w-3 h-3 text-purple-600 dark:text-purple-400" />
                                </div>
                              )}
                              {job.verificationMethods.includes("gps-location") && (
                                <div className="p-1 bg-green-100 dark:bg-green-900/20 rounded">
                                  <Navigation className="w-3 h-3 text-green-600 dark:text-green-400" />
                                </div>
                              )}
                              {job.verificationMethods.includes("wifi-network") && (
                                <div className="p-1 bg-blue-100 dark:bg-blue-900/20 rounded">
                                  <Wifi className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                                </div>
                              )}
                              {job.verificationMethods.includes("ip-address") && (
                                <div className="p-1 bg-orange-100 dark:bg-orange-900/20 rounded">
                                  <Smartphone className="w-3 h-3 text-orange-600 dark:text-orange-400" />
                                </div>
                              )}
                              {job.verificationMethods.includes("photo-verification") && (
                                <div className="p-1 bg-pink-100 dark:bg-pink-900/20 rounded">
                                  <Camera className="w-3 h-3 text-pink-600 dark:text-pink-400" />
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex gap-2 pt-1">
                            <Button
                              size="sm"
                              className="flex-1 h-7 text-xs bg-purple-600 hover:bg-purple-700 text-white"
                              onClick={() => handleViewDetails(job)}
                            >
                              <Eye className="w-3 h-3 mr-1" />
                              View Details
                            </Button>
                            {!job.clientSurvey?.submitted && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs bg-transparent border-purple-300 text-purple-600 hover:bg-purple-50 dark:border-purple-800 dark:text-purple-400 dark:hover:bg-purple-900/20"
                                onClick={() => handleFillSurvey(job)}
                              >
                                <Star className="w-3 h-3 mr-1" />
                                Fill Survey
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
              </div>
            )}

            {activeTab === "history" && (
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                {jobs
                  .filter((job) => job.status === "completed")
                  .map((job) => {
                    const statusConfig = getStatusConfig(job.status)
                    const StatusIcon = statusConfig.icon

                    return (
                      <Card
                        key={job.id}
                        className="border border-gray-200 dark:border-gray-800 hover:shadow-lg transition-all duration-300 bg-white dark:bg-gray-900"
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <div className={`w-2 h-2 rounded-full ${statusConfig.dot}`}></div>
                                <h3 className="text-base font-semibold text-gray-900 dark:text-white">{job.title}</h3>
                              </div>
                              <div className="flex items-center gap-2">
                                <Badge
                                  variant="outline"
                                  className="text-xs font-mono bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                                >
                                  {job.jobId}
                                </Badge>
                                <Badge className={`${statusConfig.color} flex items-center gap-1 text-xs font-medium`}>
                                  <StatusIcon className="w-3 h-3" />
                                  Completed
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </CardHeader>

                        <CardContent className="space-y-3">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                              <span className="text-sm text-gray-600 dark:text-gray-400">{job.schedule.date}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Timer className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                              <span className="text-sm text-gray-600 dark:text-gray-400">
                                {job.timeTracking.actualHours}h completed
                              </span>
                            </div>
                          </div>

                          {/* Survey Status */}
                          {job.clientSurvey?.submitted && (
                            <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg border border-green-200 dark:border-green-800">
                              <div className="flex items-center gap-2 mb-2">
                                <Star className="w-4 h-4 text-green-600 dark:text-green-400" />
                                <span className="text-sm font-medium text-green-700 dark:text-green-400">
                                  Survey Completed
                                </span>
                              </div>
                              <div className="flex items-center gap-2 mb-2">
                                <span className="text-sm text-green-600 dark:text-green-400">Rating:</span>
                                <div className="flex gap-1">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star
                                      key={star}
                                      className={`w-3 h-3 ${
                                        star <= (job.clientSurvey?.rating || 0)
                                          ? "text-yellow-500 fill-current"
                                          : "text-gray-300 dark:text-gray-600"
                                      }`}
                                    />
                                  ))}
                                </div>
                                <span className="text-sm font-medium text-green-700 dark:text-green-400">
                                  {job.clientSurvey.rating}/5
                                </span>
                              </div>
                              {job.clientSurvey.comments && (
                                <p className="text-sm text-green-700 dark:text-green-400 italic">
                                  "{job.clientSurvey.comments}"
                                </p>
                              )}
                            </div>
                          )}

                          {job.feedback && !job.clientSurvey?.submitted && (
                            <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700">
                              <p className="text-sm text-gray-900 dark:text-white italic">"{job.feedback}"</p>
                            </div>
                          )}

                          <div className="flex gap-2 pt-1">
                            <Button
                              size="sm"
                              className="flex-1 h-7 text-xs bg-purple-600 hover:bg-purple-700 text-white"
                              onClick={() => handleViewDetails(job)}
                            >
                              <Eye className="w-3 h-3 mr-1" />
                              View Details
                            </Button>
                            {!job.clientSurvey?.submitted && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs bg-transparent border-purple-300 text-purple-600 hover:bg-purple-50 dark:border-purple-800 dark:text-purple-400 dark:hover:bg-purple-900/20"
                                onClick={() => handleFillSurvey(job)}
                              >
                                <Star className="w-3 h-3 mr-1" />
                                Fill Survey
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
              </div>
            )}

            {activeTab === "surveys" && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                  <ClipboardList className="w-5 h-5" />
                  My Surveys
                </h3>

                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                  {jobs
                    .filter((job) => job.clientSurvey?.submitted)
                    .map((job) => (
                      <Card
                        key={job.id}
                        className="border border-gray-200 dark:border-gray-800 shadow-sm bg-white dark:bg-gray-900"
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold text-gray-900 dark:text-white">{job.title}</h4>
                              <p className="text-sm text-gray-600 dark:text-gray-400">Worker: {job.worker.name}</p>
                              <Badge
                                variant="outline"
                                className="mt-1 text-xs font-mono bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                              >
                                {job.jobId}
                              </Badge>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center gap-2 mb-3">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Rating:</span>
                            <div className="flex gap-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`w-4 h-4 ${
                                    star <= (job.clientSurvey?.rating || 0)
                                      ? "text-yellow-500 fill-current"
                                      : "text-gray-300 dark:text-gray-600"
                                  }`}
                                />
                              ))}
                            </div>
                            <span className="text-sm font-medium text-gray-900 dark:text-white">
                              {job.clientSurvey?.rating}/5
                            </span>
                          </div>
                          {job.clientSurvey?.comments && (
                            <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700 mb-3">
                              <p className="text-sm text-gray-900 dark:text-white italic">
                                "{job.clientSurvey.comments}"
                              </p>
                            </div>
                          )}
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            Submitted:{" "}
                            {job.clientSurvey?.submittedAt &&
                              new Date(job.clientSurvey.submittedAt).toLocaleDateString()}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                </div>

                {jobs.filter((job) => job.clientSurvey?.submitted).length === 0 && (
                  <Card className="border border-gray-200 dark:border-gray-800 shadow-sm bg-white dark:bg-gray-900">
                    <CardContent className="p-8 text-center">
                      <ClipboardList className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                      <h3 className="text-base font-semibold text-gray-900 dark:text-white mb-2">No Surveys Yet</h3>
                      <p className="text-gray-600 dark:text-gray-400 text-sm">
                        Your completed surveys will appear here after you submit them.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
